<!doctype html>
<html lang="en" data-theme="dark">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title><?= BASE_NAME ?> - <?= isset($title) ? $title : 'Dashboard' ?></title>
    <?= $this->renderSection('css') ?>

    <?= link_tag('assets/css/natacode.css') ?>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</head>
<style>
    :root {
        /* Dark Theme Variables */
        --dark-bg-primary: #0a0a0a;
        --dark-bg-secondary: #1a1a1a;
        --dark-bg-tertiary: #2d2d2d;
        --dark-text-primary: #ffffff;
        --dark-text-secondary: #b3b3b3;
        --dark-accent: #8b5cf6;
        --dark-accent-hover: #a78bfa;
        --dark-border: rgba(255, 255, 255, 0.1);
        --dark-shadow: rgba(0, 0, 0, 0.5);
        --dark-glass: rgba(0, 0, 0, 0.8);
        
        /* Light Theme Variables */
        --light-bg-primary: #ffffff;
        --light-bg-secondary: #f8f9fa;
        --light-bg-tertiary: #e9ecef;
        --light-text-primary: #1a1a1a;
        --light-text-secondary: #6c757d;
        --light-accent: #6d28d9;
        --light-accent-hover: #7c3aed;
        --light-border: rgba(0, 0, 0, 0.1);
        --light-shadow: rgba(0, 0, 0, 0.1);
        --light-glass: rgba(255, 255, 255, 0.9);
    }

    [data-theme="dark"] {
        --bg-primary: var(--dark-bg-primary);
        --bg-secondary: var(--dark-bg-secondary);
        --bg-tertiary: var(--dark-bg-tertiary);
        --text-primary: var(--dark-text-primary);
        --text-secondary: var(--dark-text-secondary);
        --accent: var(--dark-accent);
        --accent-hover: var(--dark-accent-hover);
        --border: var(--dark-border);
        --shadow: var(--dark-shadow);
        --glass: var(--dark-glass);
    }

    [data-theme="light"] {
        --bg-primary: var(--light-bg-primary);
        --bg-secondary: var(--light-bg-secondary);
        --bg-tertiary: var(--light-bg-tertiary);
        --text-primary: var(--light-text-primary);
        --text-secondary: var(--light-text-secondary);
        --accent: var(--light-accent);
        --accent-hover: var(--light-accent-hover);
        --border: var(--light-border);
        --shadow: var(--light-shadow);
        --glass: var(--light-glass);
    }

    * {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        background-image: url("uploads/resimler/arkaplan.png");
        font-family: 'Poppins', sans-serif !important;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-color: var(--bg-primary);
        color: var(--text-primary);
        margin: 0;
        padding: 0;
        min-height: 100vh;
        position: relative;
    }

    body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, 
            rgba(139, 92, 246, 0.05) 0%, 
            rgba(0, 0, 0, 0.1) 50%, 
            rgba(139, 92, 246, 0.05) 100%);
        z-index: -1;
        pointer-events: none;
    }

    [data-theme="light"] body::before {
        background: linear-gradient(135deg, 
            rgba(139, 92, 246, 0.1) 0%, 
            rgba(255, 255, 255, 0.3) 50%, 
            rgba(139, 92, 246, 0.1) 100%);
    }

    /* Modern Card Styles */
    .card {
        background: var(--glass);
        backdrop-filter: blur(20px);
        border: 1px solid var(--border);
        border-radius: 20px;
        box-shadow: 0 8px 32px var(--shadow);
        overflow: hidden;
        position: relative;
    }

    .card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, var(--accent), var(--accent-hover));
    }

    .card-header {
        background: linear-gradient(135deg, var(--bg-secondary), var(--bg-tertiary));
        border-bottom: 1px solid var(--border);
        color: var(--text-primary);
        font-weight: 600;
        padding: 1.5rem;
    }

    /* Modern Button Styles */
    .btn-modern {
        background: linear-gradient(135deg, var(--accent), var(--accent-hover));
        border: none;
        border-radius: 12px;
        color: white;
        font-weight: 600;
        padding: 12px 24px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
    }

    .btn-modern::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left 0.5s;
    }

    .btn-modern:hover::before {
        left: 100%;
    }

    .btn-modern:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        color: white;
    }

    .btn-modern:active {
        transform: translateY(-1px);
    }

    /* Theme Toggle Button */
    .theme-toggle {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        background: var(--glass);
        backdrop-filter: blur(20px);
        border: 1px solid var(--border);
        border-radius: 50px;
        padding: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px var(--shadow);
    }

    .theme-toggle:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 20px var(--shadow);
    }

    .theme-toggle i {
        font-size: 1.2rem;
        color: var(--accent);
    }

    /* Modern Form Controls */
    .form-control {
        background: var(--glass);
        backdrop-filter: blur(10px);
        border: 2px solid var(--border);
        border-radius: 12px;
        color: var(--text-primary);
        padding: 12px 16px;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        background: var(--glass);
        border-color: var(--accent);
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
        color: var(--text-primary);
    }

    .form-control::placeholder {
        color: var(--text-secondary);
    }

    /* Modern Table Styles */
    .table {
        background: var(--glass);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        overflow: hidden;
        color: var(--text-primary);
    }

    .table thead th {
        background: linear-gradient(135deg, var(--accent), var(--accent-hover));
        color: white;
        border: none;
        padding: 15px;
        font-weight: 600;
    }

    .table tbody td {
        background: var(--glass);
        border-color: var(--border);
        padding: 15px;
        color: var(--text-primary);
    }

    .table tbody tr:hover {
        background: rgba(139, 92, 246, 0.1);
    }

    /* Modern Navigation */
    .navbar {
        background: var(--glass);
        backdrop-filter: blur(20px);
        border-bottom: 1px solid var(--border);
        box-shadow: 0 4px 20px var(--shadow);
    }

    .navbar-brand {
        color: var(--accent) !important;
        font-weight: 700;
        font-size: 1.5rem;
    }

    .nav-link {
        color: var(--text-primary) !important;
        font-weight: 500;
        border-radius: 8px;
        margin: 0 5px;
        transition: all 0.3s ease;
    }

    .nav-link:hover {
        background: rgba(139, 92, 246, 0.1);
        color: var(--accent) !important;
    }

    /* Modern Dropdown */
    .dropdown-menu {
        background: var(--glass);
        backdrop-filter: blur(20px);
        border: 1px solid var(--border);
        border-radius: 15px;
        box-shadow: 0 8px 32px var(--shadow);
    }

    .dropdown-item {
        color: var(--text-primary);
        border-radius: 8px;
        margin: 2px 8px;
        transition: all 0.3s ease;
    }

    .dropdown-item:hover {
        background: rgba(139, 92, 246, 0.1);
        color: var(--accent);
    }

    /* Modern Container */
    .container {
        max-width: 1200px;
        padding: 20px;
    }

    /* Modern Footer */
    footer {
        background: var(--glass);
        backdrop-filter: blur(20px);
        border-top: 1px solid var(--border);
        color: var(--text-secondary);
        margin-top: auto;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .theme-toggle {
            top: 10px;
            right: 10px;
            padding: 8px;
        }
        
        .container {
            padding: 10px;
        }
    }

    /* Animation Classes */
    .fade-in {
        animation: fadeIn 0.5s ease-in;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .slide-in {
        animation: slideIn 0.5s ease-out;
    }

    @keyframes slideIn {
        from { transform: translateX(-100%); }
        to { transform: translateX(0); }
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
    }

    ::-webkit-scrollbar-track {
        background: var(--bg-secondary);
    }

    ::-webkit-scrollbar-thumb {
        background: var(--accent);
        border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--accent-hover);
    }
</style>
<body>
    <!-- Theme Toggle Button -->
    <div class="theme-toggle" onclick="toggleTheme()">
        <i class="bi bi-moon-fill" id="theme-icon"></i>
    </div>

    <!-- Start menu -->
    <?= $this->include('Layout/Header') ?>
    <!-- End of menu -->
    
    <main class="fade-in">
        <div class="container p-6 py-4 mb-2">
            <!-- Start content -->
            <?= $this->renderSection('content') ?>
            <!-- End of content -->
        </div>
    </main>
    
    <footer class="bg-body border-top py-3 text-muted">
        <div class="container">
            <small class="text-warning">&copy; <?= date('Y') ?> - <?= BASE_NAME ?></small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.0/sweetalert2.all.min.js" integrity="sha512-0UUEaq/z58JSHpPgPv8bvdhHFRswZzxJUT9y+Kld5janc9EWgGEVGfWV1hXvIvAJ8MmsR5d4XV9lsuA90xXqUQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <?= script_tag('assets/js/natacode.js') ?>

    <?= $this->renderSection('js') ?>

    <script>
        // Theme Toggle Function
        function toggleTheme() {
            const html = document.documentElement;
            const themeIcon = document.getElementById('theme-icon');
            const currentTheme = html.getAttribute('data-theme');
            
            if (currentTheme === 'dark') {
                html.setAttribute('data-theme', 'light');
                themeIcon.className = 'bi bi-sun-fill';
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-theme', 'dark');
                themeIcon.className = 'bi bi-moon-fill';
                localStorage.setItem('theme', 'dark');
            }
        }

        // Load saved theme
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme') || 'dark';
            const html = document.documentElement;
            const themeIcon = document.getElementById('theme-icon');
            
            html.setAttribute('data-theme', savedTheme);
            themeIcon.className = savedTheme === 'dark' ? 'bi bi-moon-fill' : 'bi bi-sun-fill';
        });

        // Add animation to cards
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.card');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.1}s`;
                card.classList.add('fade-in');
            });
        });
    </script>
</body>
</html>