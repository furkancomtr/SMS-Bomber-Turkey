<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<div class="login-container">
	<div class="background-image"></div>
	
	<div class="container min-vh-100 d-flex align-items-center justify-content-center position-relative">
		<div class="col-lg-6 col-md-8 col-sm-12">
			<?= $this->include('Layout/msgStatus') ?>
			
			<div class="login-panel">
				<div class="login-header">
					<h2 class="panel-title">Sign In</h2>
					<p class="panel-subtitle">Access your account</p>
				</div>
				
				<?= form_open() ?>
				<div class="input-group">
					<input type="text" class="form-input" name="username" id="username" placeholder="Username" required minlength="4">
				</div>
				<div class="input-group">
					<input type="password" class="form-input" name="password" id="password" placeholder="Password" required minlength="6">
				</div>
				<div class="forgot-password">
					<a href="#" class="forgot-link">Forgot Password?</a>
				</div>
				<div class="button-group">
					<button type="submit" class="btn-primary">
						Sign In
					</button>
					<a href="<?= site_url('register') ?>" class="btn-secondary">
						Register
					</a>
				</div>
				<?= form_close() ?>
			</div>
		</div>
	</div>
</div>

<style>

.background-image {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;a
	height: 100%;
	background-image: url('uploads/resimler/arkaplan.png');
	background-size: cover;
	background-position: center;
	background-repeat: no-repeat;
	opacity: 100;
	z-index: -1;
}

.login-panel {
	background: rgba(42, 42, 42, 0.9);
	backdrop-filter: blur(20px);
	border: 1px solid #404040;
	border-radius: 20px;
	padding: 40px 30px;
	box-shadow: 
		0 20px 60px rgba(0, 0, 0, 0.5),
		0 0 100px rgba(255, 30, 255, 0.1);
	position: relative;
	z-index: 2;
	max-width: 520px;
	width: 100%;
	animation: fadeInUp 0.8s ease-out, glow 3s ease-in-out infinite;
}

[data-theme="light"] .login-panel {
	background: rgba(255, 255, 255, 0.9);
	border: 1px solid rgba(0, 0, 0, 0.1);
	box-shadow: 
		0 20px 60px rgba(0, 0, 0, 0.1),
		0 0 100px rgba(139, 92, 246, 0.1);
}

.login-panel:hover::before { left: 100%; }

.login-header { text-align: center; margin-bottom: 25px; }

.panel-title {
	color: #c9c9c9;
	font-size: 28px;
	font-weight: 700;
	margin-bottom: 8px;
	text-shadow: 0 0 20px rgba(111, 85, 255, 0.5);
	letter-spacing: 1px;
}

[data-theme="light"] .panel-title {
	color: #1a1a1a;
	text-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
}

.panel-subtitle { color: #cccccc; font-size: 14px; letter-spacing: 0.5px; }

[data-theme="light"] .panel-subtitle { color: #6c757d; }

.input-group { margin-bottom: 18px; position: relative; }

.form-input {
	width: 100%;
	padding: 14px 16px;
	border: 2px solid #c9c9c9;
	border-radius: 12px;
	background: rgba(26, 26, 26, 0.8);
	color: #ffffff;
	font-size: 15px;
	backdrop-filter: blur(10px);
	transition: all 0.3s ease;
}

[data-theme="light"] .form-input {
	border: 2px solid rgba(0, 0, 0, 0.1);
	background: rgba(255, 255, 255, 0.9);
	color: #1a1a1a;
}

.form-input::placeholder { color: #888888; }

[data-theme="light"] .form-input::placeholder { color: #6c757d; }

.form-input:focus {
	outline: none;
	border-color: #c9c9c9;
	background: rgba(26, 26, 26, 0.9);
	box-shadow: 0 0 20px rgba(111, 85, 255, 0.3);
}

[data-theme="light"] .form-input:focus {
	border-color: #8b5cf6;
	background: rgba(255, 255, 255, 1);
	box-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
}

.forgot-password {
	text-align: right;
	margin-bottom: 20px;
}

.forgot-link {
	color: #c9c9c9f;
	text-decoration: none;
	font-size: 14px;
	transition: all 0.3s ease;
}

[data-theme="light"] .forgot-link {
	color: #6d28d9;
}

.forgot-link:hover {
	color: #c9c9c96;
	text-shadow: 0 0 10px rgba(111, 0, 255, 0.5);
}

[data-theme="light"] .forgot-link:hover {
	color: #7c3aed;
	text-shadow: 0 0 10px rgba(139, 92, 246, 0.3);
}

.button-group { display: flex; flex-direction: column; gap: 12px; margin-top: 8px; }

.btn-primary, .btn-secondary {
	width: 100%;
	padding: 14px;
	border: none;
	border-radius: 12px;
	font-size: 15px;
	font-weight: 600;
	cursor: pointer;
	transition: all 0.3s ease;
	text-decoration: none;
	text-align: center;
	text-transform: uppercase;
	letter-spacing: 1px;
	position: relative;
	overflow: hidden;
}

.btn-primary { background: linear-gradient(45deg, #c9c9c9, #4a00aa); color: #ffffff; box-shadow: 0 8px 25px rgba(111, 85, 255, 0.3); }
.btn-primary::before {
	content: '';
	position: absolute; top: 0; left: -100%; width: 100%; height: 100%;
	background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
	transition: left 0.5s;
}
.btn-primary:hover::before { left: 100%; }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 12px 35px rgba(1111, 2, 255, 0.4); color: #ffffff; }

.btn-secondary { background: linear-gradient(45deg, #404040, #505050); color: #ffffff; box-shadow: 0 8px 25px rgba(64, 64, 64, 0.3); }
.btn-secondary::before {
	content: '';
	position: absolute; top: 0; left: -100%; width: 100%; height: 100%;
	background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
	transition: left 0.5s;
}
.btn-secondary:hover::before { left: 100%; }
.btn-secondary:hover { transform: translateY(-2px); box-shadow: 0 12px 35px rgba(64, 64, 64, 0.4); color: #ffffff; }

@keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
@keyframes glow { 0%,100%{ box-shadow: 0 20px 60px rgba(0,0,0,.5), 0 0 100px rgba(111, 85, 255,.1);} 50%{ box-shadow: 0 20px 60px rgba(0,0,0,.5), 0 0 150px rgba(111, 85, 255,.2);} }

[data-theme="light"] @keyframes glow { 0%,100%{ box-shadow: 0 20px 60px rgba(0,0,0,.1), 0 0 100px rgba(139, 92, 246,.1);} 50%{ box-shadow: 0 20px 60px rgba(0,0,0,.1), 0 0 150px rgba(139, 92, 246,.2);} }
</style>

<?= $this->endSection() ?>