<?php

$servername = "localhost";
$username = "woltrax";
$password = "woltrax";
$dbname = "woltrax";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>