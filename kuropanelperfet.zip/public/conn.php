<?php

$servername = "localhost";
$username = "woltrax_WhatsApp";
$password = "woltrax_WhatsApp";
$dbname = "woltrax_WhatsApp";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>